<?php
/**
 * Plugin Name: RavenHawk Scheduled Posts
 * Plugin URI: https://ravenhawktech.com/
 * Description: Displays upcoming scheduled WordPress posts using a shortcode.
 * Version: 1.0.0
 * Author: RavenHawkTech
 * License: GPL-2.0-or-later
 * Text Domain: rht-scheduled-posts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RHT_SCHEDULED_POSTS_VERSION', '1.0.0' );
define( 'RHT_SCHEDULED_POSTS_URL', plugin_dir_url( __FILE__ ) );
define( 'RHT_SCHEDULED_POSTS_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Register assets.
 */
function rht_scheduled_posts_register_assets() {
	wp_register_style(
		'rht-scheduled-posts',
		RHT_SCHEDULED_POSTS_URL . 'assets/rht-scheduled-posts.css',
		array(),
		RHT_SCHEDULED_POSTS_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'rht_scheduled_posts_register_assets' );

/**
 * Convert common shortcode values to booleans.
 *
 * @param mixed $value Attribute value.
 * @return bool
 */
function rht_scheduled_posts_to_bool( $value ) {
	return in_array( strtolower( (string) $value ), array( '1', 'true', 'yes', 'on' ), true );
}

/**
 * Render scheduled posts shortcode.
 *
 * Usage:
 * [rht_scheduled_posts]
 * [rht_scheduled_posts limit="5" category="ai" show_excerpt="yes" show_date="yes" date_format="F j, Y g:i A"]
 *
 * @param array $atts Shortcode attributes.
 * @return string
 */
function rht_scheduled_posts_shortcode( $atts = array() ) {
	$atts = shortcode_atts(
		array(
			'limit'          => 5,
			'category'       => '',
			'show_date'      => 'yes',
			'show_excerpt'   => 'no',
			'date_format'    => get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
			'order'          => 'ASC',
			'title'          => 'Upcoming Scheduled Posts',
			'empty_message'  => 'No scheduled posts are currently queued.',
			'post_type'      => 'post',
			'link_titles'    => 'no',
		),
		$atts,
		'rht_scheduled_posts'
	);

	$limit = absint( $atts['limit'] );
	if ( 0 === $limit ) {
		$limit = 5;
	}

	$order = strtoupper( sanitize_text_field( $atts['order'] ) );
	if ( ! in_array( $order, array( 'ASC', 'DESC' ), true ) ) {
		$order = 'ASC';
	}

	$post_type = sanitize_key( $atts['post_type'] );
	if ( empty( $post_type ) ) {
		$post_type = 'post';
	}

	$query_args = array(
		'post_type'           => $post_type,
		'post_status'         => 'future',
		'posts_per_page'      => $limit,
		'orderby'             => 'date',
		'order'               => $order,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);

	$category = sanitize_title( $atts['category'] );
	if ( ! empty( $category ) && 'post' === $post_type ) {
		$query_args['category_name'] = $category;
	}

	$scheduled_posts = new WP_Query( $query_args );

	wp_enqueue_style( 'rht-scheduled-posts' );

	ob_start();

	$title         = sanitize_text_field( $atts['title'] );
	$show_date     = rht_scheduled_posts_to_bool( $atts['show_date'] );
	$show_excerpt  = rht_scheduled_posts_to_bool( $atts['show_excerpt'] );
	$link_titles   = rht_scheduled_posts_to_bool( $atts['link_titles'] );
	$date_format   = sanitize_text_field( $atts['date_format'] );
	$empty_message = sanitize_text_field( $atts['empty_message'] );

	?>
	<section class="rht-scheduled-posts" aria-label="<?php echo esc_attr( $title ); ?>">
		<?php if ( ! empty( $title ) ) : ?>
			<header class="rht-scheduled-posts__header">
				<span class="rht-scheduled-posts__eyebrow"><?php esc_html_e( 'Editorial Queue', 'rht-scheduled-posts' ); ?></span>
				<h2 class="rht-scheduled-posts__title"><?php echo esc_html( $title ); ?></h2>
			</header>
		<?php endif; ?>

		<?php if ( $scheduled_posts->have_posts() ) : ?>
			<div class="rht-scheduled-posts__list">
				<?php
				while ( $scheduled_posts->have_posts() ) :
					$scheduled_posts->the_post();

					$post_id   = get_the_ID();
					$post_date = get_post_time( $date_format, false, $post_id, true );
					?>
					<article class="rht-scheduled-posts__item">
						<div class="rht-scheduled-posts__content">
							<h3 class="rht-scheduled-posts__post-title">
								<?php if ( $link_titles && current_user_can( 'edit_post', $post_id ) ) : ?>
									<a href="<?php echo esc_url( get_edit_post_link( $post_id ) ); ?>">
										<?php echo esc_html( get_the_title() ); ?>
									</a>
								<?php else : ?>
									<?php echo esc_html( get_the_title() ); ?>
								<?php endif; ?>
							</h3>

							<?php if ( $show_date ) : ?>
								<p class="rht-scheduled-posts__date">
									<span><?php esc_html_e( 'Publishes:', 'rht-scheduled-posts' ); ?></span>
									<time datetime="<?php echo esc_attr( get_post_time( 'c', false, $post_id ) ); ?>">
										<?php echo esc_html( $post_date ); ?>
									</time>
								</p>
							<?php endif; ?>

							<?php if ( $show_excerpt ) : ?>
								<div class="rht-scheduled-posts__excerpt">
									<?php echo wp_kses_post( wpautop( get_the_excerpt() ) ); ?>
								</div>
							<?php endif; ?>
						</div>
					</article>
				<?php endwhile; ?>
			</div>
		<?php else : ?>
			<p class="rht-scheduled-posts__empty"><?php echo esc_html( $empty_message ); ?></p>
		<?php endif; ?>
	</section>
	<?php

	wp_reset_postdata();

	return ob_get_clean();
}
add_shortcode( 'rht_scheduled_posts', 'rht_scheduled_posts_shortcode' );

/**
 * Add a small shortcode reference link on the plugins screen.
 *
 * @param array $links Plugin action links.
 * @return array
 */
function rht_scheduled_posts_action_links( $links ) {
	$shortcode = '<code>[rht_scheduled_posts]</code>';
	array_unshift( $links, $shortcode );

	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'rht_scheduled_posts_action_links' );
