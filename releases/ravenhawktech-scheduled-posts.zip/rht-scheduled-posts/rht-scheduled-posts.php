<?php
/**
 * Plugin Name: RavenHawk Scheduled Posts
 * Plugin URI: https://ravenhawktech.com/
 * Description: Displays upcoming scheduled WordPress posts using a shortcode with admin shortcode reference and editable styles. Visit https://ravenhawktech.com for RavenHawkTech.
 * Version: 2.0.1
 * Author: RavenHawkTech
 * License: GPL-2.0-or-later
 * Text Domain: rht-scheduled-posts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RHT_SCHEDULED_POSTS_VERSION', '2.0.1' );
define( 'RHT_SCHEDULED_POSTS_URL', plugin_dir_url( __FILE__ ) );
define( 'RHT_SCHEDULED_POSTS_PATH', plugin_dir_path( __FILE__ ) );
define( 'RHT_SCHEDULED_POSTS_OPTIONS', 'rht_scheduled_posts_options' );

/**
 * Default admin-configurable style options.
 *
 * @return array
 */
function rht_scheduled_posts_default_options() {
	return array(
		'background_color'      => '#0f172a',
		'card_color'            => '#111827',
		'text_color'            => '#e5e7eb',
		'muted_text_color'      => '#cbd5e1',
		'heading_color'         => '#f8fafc',
		'accent_color'          => '#39ff14',
		'date_label_color'      => '#facc15',
		'empty_background'      => '#020617',
		'border_radius'         => 18,
		'card_radius'           => 14,
	);
}

/**
 * Get saved admin-configurable options.
 *
 * @return array
 */
function rht_scheduled_posts_options() {
	$saved = get_option( RHT_SCHEDULED_POSTS_OPTIONS, array() );

	return wp_parse_args( is_array( $saved ) ? $saved : array(), rht_scheduled_posts_default_options() );
}

/**
 * Sanitize admin-configurable options.
 *
 * @param array $input Raw options.
 * @return array
 */
function rht_scheduled_posts_sanitize_options( $input ) {
	$defaults = rht_scheduled_posts_default_options();
	$input    = is_array( $input ) ? $input : array();
	$output   = array();

	foreach ( array(
		'background_color',
		'card_color',
		'text_color',
		'muted_text_color',
		'heading_color',
		'accent_color',
		'date_label_color',
		'empty_background',
	) as $key ) {
		$color          = sanitize_hex_color( $input[ $key ] ?? $defaults[ $key ] );
		$output[ $key ] = $color ?: $defaults[ $key ];
	}

	$output['border_radius'] = min( 60, max( 0, absint( $input['border_radius'] ?? $defaults['border_radius'] ) ) );
	$output['card_radius']   = min( 60, max( 0, absint( $input['card_radius'] ?? $defaults['card_radius'] ) ) );

	return $output;
}

/**
 * Convert hex color to RGB.
 *
 * @param string $hex Hex color.
 * @return string
 */
function rht_scheduled_posts_hex_to_rgb( $hex ) {
	$hex = ltrim( (string) $hex, '#' );

	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}

	if ( 6 !== strlen( $hex ) ) {
		return '57,255,20';
	}

	return hexdec( substr( $hex, 0, 2 ) ) . ',' . hexdec( substr( $hex, 2, 2 ) ) . ',' . hexdec( substr( $hex, 4, 2 ) );
}

/**
 * Build inline CSS variables from saved admin style options.
 *
 * @return string
 */
function rht_scheduled_posts_inline_css() {
	$options    = rht_scheduled_posts_options();
	$accent_rgb = rht_scheduled_posts_hex_to_rgb( $options['accent_color'] );

	return '.rht-scheduled-posts{' .
		'--rht-bg-soft:' . esc_html( $options['background_color'] ) . ';' .
		'--rht-card:' . esc_html( $options['card_color'] ) . ';' .
		'--rht-text:' . esc_html( $options['text_color'] ) . ';' .
		'--rht-muted:' . esc_html( $options['muted_text_color'] ) . ';' .
		'--rht-heading:' . esc_html( $options['heading_color'] ) . ';' .
		'--rht-green:' . esc_html( $options['accent_color'] ) . ';' .
		'--rht-green-rgb:' . esc_html( $accent_rgb ) . ';' .
		'--rht-yellow:' . esc_html( $options['date_label_color'] ) . ';' .
		'--rht-empty-bg:' . esc_html( $options['empty_background'] ) . ';' .
		'--rht-radius:' . absint( $options['border_radius'] ) . 'px;' .
		'--rht-card-radius:' . absint( $options['card_radius'] ) . 'px;' .
	'}';
}


/**
 * Register assets.
 */
function rht_scheduled_posts_register_assets() {
	wp_register_style(
		'rht-scheduled-posts',
		RHT_SCHEDULED_POSTS_URL . 'assets/rht-scheduled-posts.css',
		array(),
		RHT_SCHEDULED_POSTS_VERSION
	);
	wp_add_inline_style( 'rht-scheduled-posts', rht_scheduled_posts_inline_css() );
}
add_action( 'wp_enqueue_scripts', 'rht_scheduled_posts_register_assets' );

/**
 * Register admin settings.
 */
function rht_scheduled_posts_register_settings() {
	register_setting(
		'rht_scheduled_posts_settings',
		RHT_SCHEDULED_POSTS_OPTIONS,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'rht_scheduled_posts_sanitize_options',
			'default'           => rht_scheduled_posts_default_options(),
		)
	);
}
add_action( 'admin_init', 'rht_scheduled_posts_register_settings' );

/**
 * Check if the shared RavenHawkTech parent menu already exists.
 *
 * @param string $slug Menu slug.
 * @return bool
 */
function rht_scheduled_posts_admin_menu_slug_exists( $slug ) {
	global $menu;

	if ( ! is_array( $menu ) ) {
		return false;
	}

	foreach ( $menu as $item ) {
		if ( isset( $item[2] ) && $item[2] === $slug ) {
			return true;
		}
	}

	return false;
}

/**
 * Get admin menu icon URL.
 *
 * @return string
 */
function rht_scheduled_posts_admin_icon_url() {
	$path = RHT_SCHEDULED_POSTS_PATH . 'assets/rht-admin-menu-icon.png';

	return file_exists( $path ) ? RHT_SCHEDULED_POSTS_URL . 'assets/rht-admin-menu-icon.png' : 'dashicons-calendar-alt';
}

/**
 * Get admin heading icon URL.
 *
 * @return string
 */
function rht_scheduled_posts_heading_icon_url() {
	$path = RHT_SCHEDULED_POSTS_PATH . 'assets/rht-admin-heading-icon.png';

	return file_exists( $path ) ? RHT_SCHEDULED_POSTS_URL . 'assets/rht-admin-heading-icon.png' : '';
}

/**
 * Register admin menu.
 */
function rht_scheduled_posts_admin_menu() {
	if ( ! rht_scheduled_posts_admin_menu_slug_exists( 'ravenhawktech' ) ) {
		add_menu_page(
			'RavenHawkTech',
			'RavenHawkTech',
			'manage_options',
			'ravenhawktech',
			'rht_scheduled_posts_ravenhawktech_page',
			rht_scheduled_posts_admin_icon_url(),
			81
		);
	}

	add_submenu_page(
		'ravenhawktech',
		'Scheduled Posts',
		'Scheduled Posts',
		'manage_options',
		'rht-scheduled-posts',
		'rht_scheduled_posts_settings_page'
	);
}
add_action( 'admin_menu', 'rht_scheduled_posts_admin_menu' );

/**
 * Render shared RavenHawkTech page.
 */
function rht_scheduled_posts_ravenhawktech_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$icon_url = rht_scheduled_posts_heading_icon_url();
	?>
	<div class="wrap">
		<h1>
			<?php if ( $icon_url ) : ?>
				<img src="<?php echo esc_url( $icon_url ); ?>" alt="" style="width:20px;height:20px;vertical-align:text-bottom;margin-right:6px;">
			<?php endif; ?>
			<a href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">RavenHawkTech</a>
		</h1>
		<p>RavenHawkTech WordPress tools and connectors.</p>
		<p><a class="button button-primary" href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">Visit RavenHawkTech</a></p>
	</div>
	<?php
}

/**
 * Render settings page.
 */
function rht_scheduled_posts_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$options = rht_scheduled_posts_options();
	?>
	<div class="wrap">
		<h1>RavenHawk Scheduled Posts</h1>
		<p>Displays upcoming scheduled WordPress posts using a shortcode. Visit <a href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">RavenHawkTech</a>.</p>

		<h2>Shortcode</h2>
		<p>Use this shortcode on any post, page, or widget that supports shortcodes:</p>
		<p><code>[rht_scheduled_posts]</code></p>

		<p>Advanced example:</p>
		<p><code>[rht_scheduled_posts limit="5" category="ai" show_excerpt="yes" show_date="yes"]</code></p>

		<form method="post" action="options.php">
			<?php settings_fields( 'rht_scheduled_posts_settings' ); ?>

			<h2>Styles</h2>
			<p>Customize the frontend colors without editing the plugin CSS file.</p>

			<table class="form-table" role="presentation">
				<?php
				$color_fields = array(
					'background_color' => 'Background color',
					'card_color'       => 'Card color',
					'text_color'       => 'Text color',
					'muted_text_color' => 'Muted text color',
					'heading_color'    => 'Heading color',
					'accent_color'     => 'Accent color',
					'date_label_color' => 'Date label color',
					'empty_background' => 'Empty message background',
				);

				foreach ( $color_fields as $key => $label ) :
					?>
					<tr>
						<th scope="row"><label for="rht-scheduled-posts-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td>
							<input id="rht-scheduled-posts-<?php echo esc_attr( $key ); ?>" type="color" name="<?php echo esc_attr( RHT_SCHEDULED_POSTS_OPTIONS ); ?>[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $options[ $key ] ); ?>">
							<code><?php echo esc_html( $options[ $key ] ); ?></code>
						</td>
					</tr>
				<?php endforeach; ?>
				<tr>
					<th scope="row"><label for="rht-scheduled-posts-border-radius">Outer border radius</label></th>
					<td><input id="rht-scheduled-posts-border-radius" type="number" min="0" max="60" name="<?php echo esc_attr( RHT_SCHEDULED_POSTS_OPTIONS ); ?>[border_radius]" value="<?php echo esc_attr( $options['border_radius'] ); ?>"> px</td>
				</tr>
				<tr>
					<th scope="row"><label for="rht-scheduled-posts-card-radius">Card border radius</label></th>
					<td><input id="rht-scheduled-posts-card-radius" type="number" min="0" max="60" name="<?php echo esc_attr( RHT_SCHEDULED_POSTS_OPTIONS ); ?>[card_radius]" value="<?php echo esc_attr( $options['card_radius'] ); ?>"> px</td>
				</tr>
			</table>

			<?php submit_button( 'Save Scheduled Posts Settings' ); ?>
		</form>
	</div>
	<?php
}


/**
 * Convert common shortcode values to booleans.
 *
 * @param mixed $value Attribute value.
 * @return bool
 */
function rht_scheduled_posts_to_bool( $value ) {
	return in_array( strtolower( (string) $value ), array( '1', 'true', 'yes', 'on' ), true );
}

/**
 * Render scheduled posts shortcode.
 *
 * Usage:
 * [rht_scheduled_posts]
 * [rht_scheduled_posts limit="5" category="ai" show_excerpt="yes" show_date="yes" date_format="F j, Y g:i A"]
 *
 * @param array $atts Shortcode attributes.
 * @return string
 */
function rht_scheduled_posts_shortcode( $atts = array() ) {
	$atts = shortcode_atts(
		array(
			'limit'          => 5,
			'category'       => '',
			'show_date'      => 'yes',
			'show_excerpt'   => 'no',
			'date_format'    => get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
			'order'          => 'ASC',
			'title'          => 'Upcoming Scheduled Posts',
			'empty_message'  => 'No scheduled posts are currently queued.',
			'post_type'      => 'post',
			'link_titles'    => 'no',
		),
		$atts,
		'rht_scheduled_posts'
	);

	$limit = absint( $atts['limit'] );
	if ( 0 === $limit ) {
		$limit = 5;
	}

	$order = strtoupper( sanitize_text_field( $atts['order'] ) );
	if ( ! in_array( $order, array( 'ASC', 'DESC' ), true ) ) {
		$order = 'ASC';
	}

	$post_type = sanitize_key( $atts['post_type'] );
	if ( empty( $post_type ) ) {
		$post_type = 'post';
	}

	$query_args = array(
		'post_type'           => $post_type,
		'post_status'         => 'future',
		'posts_per_page'      => $limit,
		'orderby'             => 'date',
		'order'               => $order,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);

	$category = sanitize_title( $atts['category'] );
	if ( ! empty( $category ) && 'post' === $post_type ) {
		$query_args['category_name'] = $category;
	}

	$scheduled_posts = new WP_Query( $query_args );

	wp_enqueue_style( 'rht-scheduled-posts' );

	ob_start();

	$title         = sanitize_text_field( $atts['title'] );
	$show_date     = rht_scheduled_posts_to_bool( $atts['show_date'] );
	$show_excerpt  = rht_scheduled_posts_to_bool( $atts['show_excerpt'] );
	$link_titles   = rht_scheduled_posts_to_bool( $atts['link_titles'] );
	$date_format   = sanitize_text_field( $atts['date_format'] );
	$empty_message = sanitize_text_field( $atts['empty_message'] );

	?>
	<section class="rht-scheduled-posts" aria-label="<?php echo esc_attr( $title ); ?>">
		<?php if ( ! empty( $title ) ) : ?>
			<header class="rht-scheduled-posts__header">
				<span class="rht-scheduled-posts__eyebrow"><?php esc_html_e( 'Editorial Queue', 'rht-scheduled-posts' ); ?></span>
				<h2 class="rht-scheduled-posts__title"><?php echo esc_html( $title ); ?></h2>
			</header>
		<?php endif; ?>

		<?php if ( $scheduled_posts->have_posts() ) : ?>
			<div class="rht-scheduled-posts__list">
				<?php
				while ( $scheduled_posts->have_posts() ) :
					$scheduled_posts->the_post();

					$post_id   = get_the_ID();
					$post_date = get_post_time( $date_format, false, $post_id, true );
					?>
					<article class="rht-scheduled-posts__item">
						<div class="rht-scheduled-posts__content">
							<h3 class="rht-scheduled-posts__post-title">
								<?php if ( $link_titles && current_user_can( 'edit_post', $post_id ) ) : ?>
									<a href="<?php echo esc_url( get_edit_post_link( $post_id ) ); ?>">
										<?php echo esc_html( get_the_title() ); ?>
									</a>
								<?php else : ?>
									<?php echo esc_html( get_the_title() ); ?>
								<?php endif; ?>
							</h3>

							<?php if ( $show_date ) : ?>
								<p class="rht-scheduled-posts__date">
									<span><?php esc_html_e( 'Publishes:', 'rht-scheduled-posts' ); ?></span>
									<time datetime="<?php echo esc_attr( get_post_time( 'c', false, $post_id ) ); ?>">
										<?php echo esc_html( $post_date ); ?>
									</time>
								</p>
							<?php endif; ?>

							<?php if ( $show_excerpt ) : ?>
								<div class="rht-scheduled-posts__excerpt">
									<?php echo wp_kses_post( wpautop( get_the_excerpt() ) ); ?>
								</div>
							<?php endif; ?>
						</div>
					</article>
				<?php endwhile; ?>
			</div>
		<?php else : ?>
			<p class="rht-scheduled-posts__empty"><?php echo esc_html( $empty_message ); ?></p>
		<?php endif; ?>
	</section>
	<?php

	wp_reset_postdata();

	return ob_get_clean();
}
add_shortcode( 'rht_scheduled_posts', 'rht_scheduled_posts_shortcode' );

/**
 * Add a small shortcode reference link on the plugins screen.
 *
 * @param array $links Plugin action links.
 * @return array
 */
