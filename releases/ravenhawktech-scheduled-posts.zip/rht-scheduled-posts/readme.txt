=== RavenHawk Scheduled Posts ===
Contributors: ravenhawktech
Tags: scheduled posts, shortcode, editorial calendar, future posts
Requires at least: 6.0
Tested up to: 6.5
Stable tag: 2.0.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Display upcoming scheduled WordPress posts with a dark-theme-safe shortcode, admin shortcode reference, and editable style settings.

== Description ==

RavenHawk Scheduled Posts adds a simple shortcode for displaying posts that are scheduled to publish in the future.

Basic shortcode:

[rht_scheduled_posts]

Advanced example:

[rht_scheduled_posts limit="5" category="ai" show_excerpt="yes" show_date="yes"]

== Admin Settings ==

Open RavenHawkTech > Scheduled Posts to view the shortcode and adjust frontend style colors.

== Shortcode Attributes ==

limit:
Number of scheduled posts to show. Default: 5.

category:
Optional post category slug. Only applies to the default post type.

show_date:
yes or no. Default: yes.

show_excerpt:
yes or no. Default: no.

date_format:
Optional PHP/WordPress date format. Default uses the site's date and time settings.

order:
ASC or DESC. Default: ASC.

title:
Section title. Default: Upcoming Scheduled Posts.

empty_message:
Message shown when no scheduled posts exist.

post_type:
Post type to query. Default: post.

link_titles:
yes or no. Default: no. When enabled, users who can edit the post will see title links to the editor.

== Installation ==

1. Upload the plugin folder to /wp-content/plugins/.
2. Activate RavenHawk Scheduled Posts.
3. Add [rht_scheduled_posts] to any post, page, or widget that supports shortcodes.

== Changelog ==

= 2.0.0 =
Added RavenHawkTech admin menu grouping, shortcode reference page, and editable style settings.

= 1.0.0 =
Initial release.
